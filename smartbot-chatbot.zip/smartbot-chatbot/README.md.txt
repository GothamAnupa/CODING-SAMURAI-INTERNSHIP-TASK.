SmartBot – Rule-Based Python Chatbot

SmartBot is a friendly rule-based chatbot built with Python. It can:

Greet users
Ask how you're feeling
Perform math operations (add, subtract, multiply, divide)
Tell funny jokes
Show current date and time
Help you with built-in commands
🚀 Getting Started
Prerequisites
Python 3
How to Run
``bash

python smartbot.py